class java {
    public static void main(String args[]) {
        int arr[] = { 12, 13, 14, 15 };
        for (int i : arr) {
            arr[i]++;
        }
        System.out.print(arr);
    }

}